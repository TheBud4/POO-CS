namespace HerancaPorImplementacao.Models;

public interface IAtividadeEscolar {
    void ExecutarAtividade();
}